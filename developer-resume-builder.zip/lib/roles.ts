import type { LucideIcon } from 'lucide-react'
import {
  Code2,
  Server,
  Layers,
  Smartphone,
  Cloud,
  Database,
  Brain,
  ShieldCheck,
  PenTool,
  Megaphone,
  TrendingUp,
  Users,
  Briefcase,
  GraduationCap,
  Stethoscope,
  Scale,
} from 'lucide-react'

export type RoleCategory = 'technical' | 'non-technical'

export type Role = {
  id: string
  name: string
  category: RoleCategory
  icon: LucideIcon
  blurb: string
  headlineExample: string
  recommendedTemplates: string[]
  suggestedSkillGroups: { name: string; skills: string[] }[]
}

export const CATEGORIES: {
  id: RoleCategory
  label: string
  description: string
}[] = [
  {
    id: 'technical',
    label: 'Tech & IT roles',
    description:
      'Engineering, data, and infrastructure roles. Templates emphasize skills, projects, and impact.',
  },
  {
    id: 'non-technical',
    label: 'Non-technical roles',
    description:
      'Business, creative, and operations roles. Templates emphasize achievements and narrative.',
  },
]

export const ROLES: Role[] = [
  {
    id: 'frontend',
    name: 'Frontend Developer',
    category: 'technical',
    icon: Code2,
    blurb: 'React, UI engineering, design systems',
    headlineExample: 'Frontend Developer · React & TypeScript',
    recommendedTemplates: ['technical', 'modern', 'minimal'],
    suggestedSkillGroups: [
      { name: 'Languages', skills: ['TypeScript', 'JavaScript', 'HTML', 'CSS'] },
      { name: 'Frameworks', skills: ['React', 'Next.js', 'Tailwind CSS'] },
      { name: 'Tools', skills: ['Git', 'Vite', 'Figma', 'Jest'] },
    ],
  },
  {
    id: 'backend',
    name: 'Backend Developer',
    category: 'technical',
    icon: Server,
    blurb: 'APIs, databases, system design',
    headlineExample: 'Backend Engineer · Node.js & PostgreSQL',
    recommendedTemplates: ['technical', 'compact', 'modern'],
    suggestedSkillGroups: [
      { name: 'Languages', skills: ['Go', 'Python', 'Node.js', 'SQL'] },
      { name: 'Data', skills: ['PostgreSQL', 'Redis', 'MongoDB'] },
      { name: 'Infra', skills: ['Docker', 'REST', 'GraphQL', 'gRPC'] },
    ],
  },
  {
    id: 'fullstack',
    name: 'Full Stack Developer',
    category: 'technical',
    icon: Layers,
    blurb: 'End-to-end product engineering',
    headlineExample: 'Full Stack Engineer · React + Node',
    recommendedTemplates: ['technical', 'modern', 'compact'],
    suggestedSkillGroups: [
      { name: 'Frontend', skills: ['React', 'Next.js', 'TypeScript'] },
      { name: 'Backend', skills: ['Node.js', 'PostgreSQL', 'Prisma'] },
      { name: 'DevOps', skills: ['Docker', 'Vercel', 'CI/CD'] },
    ],
  },
  {
    id: 'mobile',
    name: 'Mobile Developer',
    category: 'technical',
    icon: Smartphone,
    blurb: 'iOS, Android, cross-platform apps',
    headlineExample: 'Mobile Developer · React Native & Swift',
    recommendedTemplates: ['modern', 'technical', 'minimal'],
    suggestedSkillGroups: [
      { name: 'Platforms', skills: ['iOS', 'Android', 'React Native'] },
      { name: 'Languages', skills: ['Swift', 'Kotlin', 'Dart'] },
      { name: 'Tools', skills: ['Xcode', 'Firebase', 'Fastlane'] },
    ],
  },
  {
    id: 'devops',
    name: 'DevOps / SRE',
    category: 'technical',
    icon: Cloud,
    blurb: 'CI/CD, cloud, reliability',
    headlineExample: 'DevOps Engineer · AWS & Kubernetes',
    recommendedTemplates: ['technical', 'compact', 'modern'],
    suggestedSkillGroups: [
      { name: 'Cloud', skills: ['AWS', 'GCP', 'Azure'] },
      { name: 'Orchestration', skills: ['Kubernetes', 'Docker', 'Terraform'] },
      { name: 'Observability', skills: ['Prometheus', 'Grafana', 'Datadog'] },
    ],
  },
  {
    id: 'data',
    name: 'Data Scientist',
    category: 'technical',
    icon: Database,
    blurb: 'ML, analytics, experimentation',
    headlineExample: 'Data Scientist · Python & ML',
    recommendedTemplates: ['technical', 'minimal', 'modern'],
    suggestedSkillGroups: [
      { name: 'Languages', skills: ['Python', 'R', 'SQL'] },
      { name: 'ML', skills: ['PyTorch', 'scikit-learn', 'TensorFlow'] },
      { name: 'Data', skills: ['Pandas', 'Spark', 'Airflow'] },
    ],
  },
  {
    id: 'ml',
    name: 'AI / ML Engineer',
    category: 'technical',
    icon: Brain,
    blurb: 'Model training, MLOps, LLMs',
    headlineExample: 'ML Engineer · LLMs & MLOps',
    recommendedTemplates: ['technical', 'modern', 'compact'],
    suggestedSkillGroups: [
      { name: 'ML', skills: ['PyTorch', 'Transformers', 'LangChain'] },
      { name: 'Infra', skills: ['CUDA', 'Ray', 'Kubernetes'] },
      { name: 'Languages', skills: ['Python', 'C++', 'SQL'] },
    ],
  },
  {
    id: 'security',
    name: 'Security Engineer',
    category: 'technical',
    icon: ShieldCheck,
    blurb: 'AppSec, infrastructure security',
    headlineExample: 'Security Engineer · AppSec & Cloud',
    recommendedTemplates: ['technical', 'compact', 'classic'],
    suggestedSkillGroups: [
      { name: 'Security', skills: ['Penetration Testing', 'SIEM', 'IAM'] },
      { name: 'Tools', skills: ['Burp Suite', 'Wireshark', 'Metasploit'] },
      { name: 'Cloud', skills: ['AWS', 'Zero Trust', 'Terraform'] },
    ],
  },
  {
    id: 'product-designer',
    name: 'Product Designer',
    category: 'non-technical',
    icon: PenTool,
    blurb: 'UX, UI, design systems',
    headlineExample: 'Product Designer · UX & Design Systems',
    recommendedTemplates: ['elegant', 'minimal', 'modern'],
    suggestedSkillGroups: [
      { name: 'Design', skills: ['UX Research', 'Wireframing', 'Prototyping'] },
      { name: 'Tools', skills: ['Figma', 'Sketch', 'Framer'] },
      { name: 'Skills', skills: ['Design Systems', 'Accessibility', 'Usability'] },
    ],
  },
  {
    id: 'marketing',
    name: 'Marketing Manager',
    category: 'non-technical',
    icon: Megaphone,
    blurb: 'Growth, brand, campaigns',
    headlineExample: 'Marketing Manager · Growth & Brand',
    recommendedTemplates: ['elegant', 'classic', 'modern'],
    suggestedSkillGroups: [
      { name: 'Marketing', skills: ['SEO', 'Content', 'Email', 'Paid Ads'] },
      { name: 'Analytics', skills: ['GA4', 'HubSpot', 'A/B Testing'] },
      { name: 'Skills', skills: ['Strategy', 'Copywriting', 'Branding'] },
    ],
  },
  {
    id: 'sales',
    name: 'Sales / Account Exec',
    category: 'non-technical',
    icon: TrendingUp,
    blurb: 'Pipeline, closing, accounts',
    headlineExample: 'Account Executive · SaaS Sales',
    recommendedTemplates: ['classic', 'elegant', 'compact'],
    suggestedSkillGroups: [
      { name: 'Sales', skills: ['Prospecting', 'Negotiation', 'Closing'] },
      { name: 'Tools', skills: ['Salesforce', 'Outreach', 'HubSpot'] },
      { name: 'Skills', skills: ['Account Management', 'Forecasting'] },
    ],
  },
  {
    id: 'pm',
    name: 'Product Manager',
    category: 'non-technical',
    icon: Briefcase,
    blurb: 'Roadmaps, discovery, delivery',
    headlineExample: 'Product Manager · B2B SaaS',
    recommendedTemplates: ['modern', 'elegant', 'minimal'],
    suggestedSkillGroups: [
      { name: 'Product', skills: ['Roadmapping', 'User Research', 'Discovery'] },
      { name: 'Tools', skills: ['Jira', 'Amplitude', 'Figma'] },
      { name: 'Skills', skills: ['Prioritization', 'Stakeholder Mgmt'] },
    ],
  },
  {
    id: 'hr',
    name: 'HR / People Ops',
    category: 'non-technical',
    icon: Users,
    blurb: 'Recruiting, culture, operations',
    headlineExample: 'People Operations Manager',
    recommendedTemplates: ['classic', 'elegant', 'minimal'],
    suggestedSkillGroups: [
      { name: 'People', skills: ['Recruiting', 'Onboarding', 'L&D'] },
      { name: 'Tools', skills: ['Workday', 'Greenhouse', 'BambooHR'] },
      { name: 'Skills', skills: ['Employee Relations', 'Compensation'] },
    ],
  },
  {
    id: 'teacher',
    name: 'Educator / Teacher',
    category: 'non-technical',
    icon: GraduationCap,
    blurb: 'Curriculum, instruction, mentoring',
    headlineExample: 'High School Educator · STEM',
    recommendedTemplates: ['classic', 'elegant', 'minimal'],
    suggestedSkillGroups: [
      { name: 'Teaching', skills: ['Curriculum Design', 'Assessment'] },
      { name: 'Skills', skills: ['Classroom Mgmt', 'Mentoring', 'EdTech'] },
    ],
  },
  {
    id: 'healthcare',
    name: 'Healthcare Professional',
    category: 'non-technical',
    icon: Stethoscope,
    blurb: 'Clinical, patient care, operations',
    headlineExample: 'Registered Nurse · Acute Care',
    recommendedTemplates: ['classic', 'minimal', 'elegant'],
    suggestedSkillGroups: [
      { name: 'Clinical', skills: ['Patient Care', 'Triage', 'EHR'] },
      { name: 'Skills', skills: ['BLS/ACLS', 'Documentation', 'Team Care'] },
    ],
  },
  {
    id: 'finance',
    name: 'Finance / Accounting',
    category: 'non-technical',
    icon: Scale,
    blurb: 'Analysis, reporting, compliance',
    headlineExample: 'Financial Analyst · FP&A',
    recommendedTemplates: ['classic', 'compact', 'minimal'],
    suggestedSkillGroups: [
      { name: 'Finance', skills: ['Modeling', 'Forecasting', 'Valuation'] },
      { name: 'Tools', skills: ['Excel', 'SAP', 'Tableau'] },
      { name: 'Skills', skills: ['Reporting', 'Budgeting', 'GAAP'] },
    ],
  },
]

export function getRole(id: string): Role | undefined {
  return ROLES.find((r) => r.id === id)
}

export function rolesByCategory(category: RoleCategory): Role[] {
  return ROLES.filter((r) => r.category === category)
}
