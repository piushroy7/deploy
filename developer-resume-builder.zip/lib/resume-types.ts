export type ExperienceItem = {
  id: string
  company: string
  role: string
  location: string
  startDate: string
  endDate: string
  current: boolean
  bullets: string[]
}

export type EducationItem = {
  id: string
  school: string
  degree: string
  field: string
  location: string
  startDate: string
  endDate: string
}

export type ProjectItem = {
  id: string
  name: string
  description: string
  link: string
  tech: string[]
}

export type CertificationItem = {
  id: string
  name: string
  issuer: string
  date: string
}

export type SkillGroup = {
  id: string
  name: string
  skills: string[]
}

export type ResumeData = {
  // identity
  fullName: string
  headline: string
  email: string
  phone: string
  location: string
  website: string
  linkedin: string
  github: string
  // body
  summary: string
  experience: ExperienceItem[]
  education: EducationItem[]
  skillGroups: SkillGroup[]
  projects: ProjectItem[]
  certifications: CertificationItem[]
  // meta
  roleId: string
  templateId: string
  accentColor: string
}

export const ACCENT_PRESETS: { name: string; value: string }[] = [
  { name: 'Indigo', value: '#4f5bd5' },
  { name: 'Ocean', value: '#0e7490' },
  { name: 'Emerald', value: '#047857' },
  { name: 'Slate', value: '#334155' },
  { name: 'Crimson', value: '#b91c1c' },
  { name: 'Amber', value: '#b45309' },
]

export function emptyResume(): ResumeData {
  return {
    fullName: '',
    headline: '',
    email: '',
    phone: '',
    location: '',
    website: '',
    linkedin: '',
    github: '',
    summary: '',
    experience: [],
    education: [],
    skillGroups: [],
    projects: [],
    certifications: [],
    roleId: '',
    templateId: '',
    accentColor: ACCENT_PRESETS[0].value,
  }
}

export function uid(): string {
  return Math.random().toString(36).slice(2, 10)
}
