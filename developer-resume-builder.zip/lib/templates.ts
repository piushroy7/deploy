export type TemplateId =
  | 'modern'
  | 'technical'
  | 'minimal'
  | 'classic'
  | 'elegant'
  | 'compact'

export type TemplateMeta = {
  id: TemplateId
  name: string
  tagline: string
  description: string
  layout: 'sidebar' | 'single' | 'two-column' | 'centered'
  bestFor: string
}

export const TEMPLATES: TemplateMeta[] = [
  {
    id: 'modern',
    name: 'Modern',
    tagline: 'Accent sidebar',
    description:
      'A confident two-tone layout with a colored sidebar for contact, skills, and links.',
    layout: 'sidebar',
    bestFor: 'Most roles',
  },
  {
    id: 'technical',
    name: 'Technical',
    tagline: 'Dev-focused',
    description:
      'Monospace accents, a prominent skills matrix, and a projects section built for engineers.',
    layout: 'single',
    bestFor: 'Engineering & data',
  },
  {
    id: 'minimal',
    name: 'Minimal',
    tagline: 'Clean & airy',
    description:
      'Generous whitespace and quiet typography that lets your content speak for itself.',
    layout: 'single',
    bestFor: 'Any role',
  },
  {
    id: 'classic',
    name: 'Classic',
    tagline: 'Timeless serif',
    description:
      'A traditional, ATS-friendly serif resume trusted across corporate and academic settings.',
    layout: 'single',
    bestFor: 'Corporate & formal',
  },
  {
    id: 'elegant',
    name: 'Elegant',
    tagline: 'Centered header',
    description:
      'A refined centered header with subtle dividers — polished and personable.',
    layout: 'centered',
    bestFor: 'Creative & business',
  },
  {
    id: 'compact',
    name: 'Compact',
    tagline: 'Dense two-column',
    description:
      'A space-efficient two-column grid that fits a lot of experience on a single page.',
    layout: 'two-column',
    bestFor: 'Senior & detailed',
  },
]

export function getTemplate(id: string): TemplateMeta | undefined {
  return TEMPLATES.find((t) => t.id === id)
}
