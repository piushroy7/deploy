'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react'
import {
  type ResumeData,
  emptyResume,
  uid,
} from '@/lib/resume-types'
import { getRole } from '@/lib/roles'

const STORAGE_KEY = 'resumint:v1'

type ResumeContextValue = {
  data: ResumeData
  hydrated: boolean
  update: (patch: Partial<ResumeData>) => void
  setField: <K extends keyof ResumeData>(key: K, value: ResumeData[K]) => void
  selectRole: (roleId: string) => void
  selectTemplate: (templateId: string) => void
  reset: () => void
  loadSample: () => void
}

const ResumeContext = createContext<ResumeContextValue | null>(null)

export function ResumeProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<ResumeData>(emptyResume)
  const [hydrated, setHydrated] = useState(false)
  const firstLoad = useRef(true)

  // hydrate from localStorage once
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw) as ResumeData
        setData({ ...emptyResume(), ...parsed })
      }
    } catch {
      // ignore corrupt storage
    }
    setHydrated(true)
  }, [])

  // persist on change (after hydration)
  useEffect(() => {
    if (!hydrated) return
    if (firstLoad.current) {
      firstLoad.current = false
      return
    }
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
    } catch {
      // storage may be full / unavailable
    }
  }, [data, hydrated])

  const update = useCallback((patch: Partial<ResumeData>) => {
    setData((prev) => ({ ...prev, ...patch }))
  }, [])

  const setField = useCallback(
    <K extends keyof ResumeData>(key: K, value: ResumeData[K]) => {
      setData((prev) => ({ ...prev, [key]: value }))
    },
    [],
  )

  const selectRole = useCallback((roleId: string) => {
    setData((prev) => {
      const role = getRole(roleId)
      const next: ResumeData = { ...prev, roleId }
      // seed headline + skill groups only if empty, so we don't clobber edits
      if (role) {
        if (!prev.headline) next.headline = role.headlineExample
        if (prev.skillGroups.length === 0) {
          next.skillGroups = role.suggestedSkillGroups.map((g) => ({
            id: uid(),
            name: g.name,
            skills: [...g.skills],
          }))
        }
      }
      return next
    })
  }, [])

  const selectTemplate = useCallback((templateId: string) => {
    setData((prev) => ({ ...prev, templateId }))
  }, [])

  const reset = useCallback(() => {
    setData(emptyResume())
    try {
      localStorage.removeItem(STORAGE_KEY)
    } catch {
      // ignore
    }
  }, [])

  const loadSample = useCallback(() => {
    setData((prev) => ({ ...sampleResume(prev.roleId, prev.templateId, prev.accentColor) }))
  }, [])

  return (
    <ResumeContext.Provider
      value={{
        data,
        hydrated,
        update,
        setField,
        selectRole,
        selectTemplate,
        reset,
        loadSample,
      }}
    >
      {children}
    </ResumeContext.Provider>
  )
}

export function useResume() {
  const ctx = useContext(ResumeContext)
  if (!ctx) throw new Error('useResume must be used within ResumeProvider')
  return ctx
}

function sampleResume(
  roleId: string,
  templateId: string,
  accentColor: string,
): ResumeData {
  return {
    fullName: 'Jordan Avery',
    headline: 'Senior Full Stack Engineer · React & Node',
    email: 'jordan.avery@email.com',
    phone: '(415) 555-0142',
    location: 'San Francisco, CA',
    website: 'jordanavery.dev',
    linkedin: 'linkedin.com/in/jordanavery',
    github: 'github.com/jordanavery',
    summary:
      'Full stack engineer with 7+ years building performant web products end to end. I lead small teams, sweat the details on UX, and care deeply about shipping reliable software that users love.',
    experience: [
      {
        id: uid(),
        company: 'Northwind Labs',
        role: 'Senior Software Engineer',
        location: 'San Francisco, CA',
        startDate: 'Jan 2022',
        endDate: '',
        current: true,
        bullets: [
          'Led the rebuild of the customer dashboard in Next.js, cutting load time by 48% and lifting engagement 22%.',
          'Designed a typed API layer adopted by 6 product teams, reducing integration bugs by a third.',
          'Mentored 4 engineers and established the team’s code review and testing standards.',
        ],
      },
      {
        id: uid(),
        company: 'Brightside',
        role: 'Software Engineer',
        location: 'Remote',
        startDate: 'Jun 2019',
        endDate: 'Dec 2021',
        current: false,
        bullets: [
          'Shipped a real-time notifications system handling 2M+ events per day.',
          'Migrated the monolith to a modular service architecture with zero downtime.',
        ],
      },
    ],
    education: [
      {
        id: uid(),
        school: 'University of California, Berkeley',
        degree: 'B.S.',
        field: 'Computer Science',
        location: 'Berkeley, CA',
        startDate: '2015',
        endDate: '2019',
      },
    ],
    skillGroups: [
      { id: uid(), name: 'Frontend', skills: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS'] },
      { id: uid(), name: 'Backend', skills: ['Node.js', 'PostgreSQL', 'Prisma', 'Redis'] },
      { id: uid(), name: 'DevOps', skills: ['Docker', 'AWS', 'CI/CD', 'Vercel'] },
    ],
    projects: [
      {
        id: uid(),
        name: 'OpenMetrics',
        description:
          'Open-source analytics dashboard with 3k+ GitHub stars and a plugin ecosystem.',
        link: 'github.com/jordanavery/openmetrics',
        tech: ['Next.js', 'ClickHouse', 'tRPC'],
      },
    ],
    certifications: [
      {
        id: uid(),
        name: 'AWS Certified Solutions Architect',
        issuer: 'Amazon Web Services',
        date: '2023',
      },
    ],
    roleId: roleId || 'fullstack',
    templateId: templateId || 'modern',
    accentColor,
  }
}
