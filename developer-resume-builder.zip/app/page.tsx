import { ResumeProvider } from '@/lib/resume-context'
import { AppFlow } from '@/components/app-flow'

export default function Page() {
  return (
    <ResumeProvider>
      <AppFlow />
    </ResumeProvider>
  )
}
