'use client'

import { useEffect, useState } from 'react'
import { RotateCcw, Wand2 } from 'lucide-react'
import { useResume } from '@/lib/resume-context'
import { AppShell } from '@/components/app-shell'
import { StageRole } from '@/components/stage-role'
import { StageTemplate } from '@/components/stage-template'
import { StageBuild } from '@/components/stage-build'
import { Button } from '@/components/ui/button'

type Stage = 'role' | 'template' | 'build'

export function AppFlow() {
  const { data, hydrated, reset, loadSample } = useResume()
  const [stage, setStage] = useState<Stage>('role')
  const [init, setInit] = useState(false)

  // pick the right starting stage once storage has hydrated
  useEffect(() => {
    if (!hydrated || init) return
    if (data.templateId) setStage('build')
    else if (data.roleId) setStage('template')
    else setStage('role')
    setInit(true)
  }, [hydrated, init, data.templateId, data.roleId])

  function startOver() {
    reset()
    setStage('role')
  }

  function useSample() {
    loadSample()
    setStage('build')
  }

  const right =
    stage === 'role' ? (
      <Button variant="outline" size="sm" onClick={useSample}>
        <Wand2 className="h-4 w-4" /> Try a sample
      </Button>
    ) : (
      <Button variant="ghost" size="sm" onClick={startOver}>
        <RotateCcw className="h-4 w-4" /> Start over
      </Button>
    )

  if (!hydrated) {
    return (
      <AppShell>
        <div className="flex h-[60vh] items-center justify-center text-sm text-muted-foreground">
          Loading your workspace…
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell right={right}>
      {stage === 'role' && <StageRole onNext={() => setStage('template')} />}
      {stage === 'template' && (
        <StageTemplate
          onNext={() => setStage('build')}
          onBack={() => setStage('role')}
        />
      )}
      {stage === 'build' && (
        <StageBuild onBackToTemplates={() => setStage('template')} />
      )}
    </AppShell>
  )
}
