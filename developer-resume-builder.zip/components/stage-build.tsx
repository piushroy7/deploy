'use client'

import { useState } from 'react'
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Eye,
  Pencil,
  User,
  AlignLeft,
  Briefcase,
  FolderGit2,
  GraduationCap,
  Wrench,
  Award,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { useResume } from '@/lib/resume-context'
import { getRole } from '@/lib/roles'
import { getTemplate } from '@/lib/templates'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { cn } from '@/lib/utils'
import {
  BasicsStep,
  SummaryStep,
  ExperienceStep,
  ProjectsStep,
  EducationStep,
  SkillsStep,
  CertificationsStep,
} from '@/components/build/steps'
import { PreviewPane } from '@/components/resume/preview-pane'

type Step = {
  key: string
  label: string
  description: string
  icon: LucideIcon
  Component: () => React.ReactElement
}

const STEPS: Step[] = [
  {
    key: 'basics',
    label: 'Basics',
    description: 'Your name, title, and contact details.',
    icon: User,
    Component: BasicsStep,
  },
  {
    key: 'summary',
    label: 'Summary',
    description: 'A short pitch at the top of your resume.',
    icon: AlignLeft,
    Component: SummaryStep,
  },
  {
    key: 'experience',
    label: 'Experience',
    description: 'Your work history and biggest wins.',
    icon: Briefcase,
    Component: ExperienceStep,
  },
  {
    key: 'projects',
    label: 'Projects',
    description: 'Notable projects, side projects, or portfolio work.',
    icon: FolderGit2,
    Component: ProjectsStep,
  },
  {
    key: 'education',
    label: 'Education',
    description: 'Degrees, schools, and coursework.',
    icon: GraduationCap,
    Component: EducationStep,
  },
  {
    key: 'skills',
    label: 'Skills',
    description: 'Grouped skills that match the role.',
    icon: Wrench,
    Component: SkillsStep,
  },
  {
    key: 'extras',
    label: 'Certifications',
    description: 'Certifications, licenses, and awards.',
    icon: Award,
    Component: CertificationsStep,
  },
]

export function StageBuild({ onBackToTemplates }: { onBackToTemplates: () => void }) {
  const { data } = useResume()
  const [mode, setMode] = useState<'edit' | 'preview'>('edit')
  const [step, setStep] = useState(0)

  const role = getRole(data.roleId)
  const template = getTemplate(data.templateId)
  const Current = STEPS[step].Component
  const progress = Math.round(((step + 1) / STEPS.length) * 100)
  const isLast = step === STEPS.length - 1

  if (mode === 'preview') {
    return (
      <div className="mx-auto max-w-6xl px-4 py-6 md:py-8">
        <div className="no-print mb-5 flex flex-wrap items-center justify-between gap-3">
          <Button variant="ghost" onClick={() => setMode('edit')}>
            <Pencil className="h-4 w-4" /> Back to editing
          </Button>
          <p className="text-sm text-muted-foreground">
            Live preview &middot; {template?.name} template
          </p>
        </div>
        <PreviewPane />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 md:py-8">
      {/* top bar */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <button
          onClick={onBackToTemplates}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          {role?.name}
          {template ? ` · ${template.name}` : ''}
        </button>
        <Button onClick={() => setMode('preview')}>
          <Eye className="h-4 w-4" /> Preview &amp; export
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr]">
        {/* stepper */}
        <aside className="lg:sticky lg:top-20 lg:self-start">
          {/* mobile progress */}
          <div className="lg:hidden">
            <div className="mb-2 flex items-center justify-between text-sm">
              <span className="font-medium">
                Step {step + 1} of {STEPS.length}
              </span>
              <span className="text-muted-foreground">{STEPS[step].label}</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* desktop vertical stepper */}
          <nav className="hidden space-y-1 lg:block">
            {STEPS.map((s, i) => {
              const Icon = s.icon
              const active = i === step
              const done = i < step
              return (
                <button
                  key={s.key}
                  onClick={() => setStep(i)}
                  className={cn(
                    'flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm transition-colors',
                    active
                      ? 'bg-primary/10 font-medium text-foreground'
                      : 'text-muted-foreground hover:bg-secondary',
                  )}
                >
                  <span
                    className={cn(
                      'flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-xs',
                      active
                        ? 'border-primary bg-primary text-primary-foreground'
                        : done
                          ? 'border-primary/40 bg-primary/10 text-primary'
                          : 'border-border text-muted-foreground',
                    )}
                  >
                    {done ? <Check className="h-3.5 w-3.5" /> : <Icon className="h-3.5 w-3.5" />}
                  </span>
                  {s.label}
                </button>
              )
            })}
          </nav>
        </aside>

        {/* form panel */}
        <section className="min-w-0">
          <div className="rounded-xl border border-border bg-card p-5 md:p-6">
            <div className="mb-5">
              <h2 className="text-xl font-bold tracking-tight text-card-foreground">
                {STEPS[step].label}
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                {STEPS[step].description}
              </p>
            </div>

            <Current />

            <div className="mt-6 flex items-center justify-between border-t border-border pt-4">
              <Button
                variant="outline"
                disabled={step === 0}
                onClick={() => setStep((s) => Math.max(0, s - 1))}
              >
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              {isLast ? (
                <Button onClick={() => setMode('preview')}>
                  <Eye className="h-4 w-4" /> Preview &amp; export
                </Button>
              ) : (
                <Button onClick={() => setStep((s) => Math.min(STEPS.length - 1, s + 1))}>
                  Next <ArrowRight className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
