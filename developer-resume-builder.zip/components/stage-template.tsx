'use client'

import { ArrowLeft, Check, Star } from 'lucide-react'
import { TEMPLATES } from '@/lib/templates'
import { getRole } from '@/lib/roles'
import { useResume } from '@/lib/resume-context'
import { TemplateRenderer } from '@/components/resume/template-renderer'
import { type ResumeData, emptyResume, uid } from '@/lib/resume-types'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

function thumbData(accent: string, templateId: string): ResumeData {
  return {
    ...emptyResume(),
    fullName: 'Alex Morgan',
    headline: 'Senior Engineer',
    email: 'alex@email.com',
    phone: '(555) 010-2030',
    location: 'New York, NY',
    website: 'alexmorgan.dev',
    linkedin: 'in/alexmorgan',
    summary:
      'Engineer focused on building reliable, well-crafted products with measurable impact across teams.',
    experience: [
      {
        id: uid(),
        company: 'Acme Corp',
        role: 'Senior Engineer',
        location: 'Remote',
        startDate: '2022',
        endDate: '',
        current: true,
        bullets: [
          'Led a platform rebuild that improved performance by 40%.',
          'Mentored engineers and set team-wide quality standards.',
        ],
      },
      {
        id: uid(),
        company: 'Globex',
        role: 'Engineer',
        location: 'NYC',
        startDate: '2019',
        endDate: '2022',
        current: false,
        bullets: ['Shipped core features used by millions of users.'],
      },
    ],
    education: [
      {
        id: uid(),
        school: 'State University',
        degree: 'B.S.',
        field: 'Computer Science',
        location: '',
        startDate: '2015',
        endDate: '2019',
      },
    ],
    skillGroups: [
      { id: uid(), name: 'Core', skills: ['TypeScript', 'React', 'Node.js'] },
      { id: uid(), name: 'Data', skills: ['PostgreSQL', 'Redis'] },
    ],
    projects: [
      {
        id: uid(),
        name: 'OpenTool',
        description: 'A popular open-source developer utility.',
        link: '',
        tech: ['Next.js', 'tRPC'],
      },
    ],
    certifications: [
      { id: uid(), name: 'AWS Solutions Architect', issuer: 'AWS', date: '2023' },
    ],
    accentColor: accent,
    templateId,
  }
}

function TemplateThumb({ templateId, accent }: { templateId: string; accent: string }) {
  return (
    <div className="pointer-events-none relative h-[200px] w-full overflow-hidden rounded-t-xl border-b border-border bg-white">
      <div
        className="absolute left-0 top-0 origin-top-left"
        style={{ width: 850, transform: 'scale(0.32)' }}
      >
        <TemplateRenderer data={thumbData(accent, templateId)} />
      </div>
    </div>
  )
}

export function StageTemplate({
  onNext,
  onBack,
}: {
  onNext: () => void
  onBack: () => void
}) {
  const { data, selectTemplate } = useResume()
  const role = getRole(data.roleId)
  const recommended = role?.recommendedTemplates ?? []

  // recommended first, then the rest
  const ordered = [...TEMPLATES].sort((a, b) => {
    const ai = recommended.indexOf(a.id)
    const bi = recommended.indexOf(b.id)
    if (ai === -1 && bi === -1) return 0
    if (ai === -1) return 1
    if (bi === -1) return -1
    return ai - bi
  })

  function pick(id: string) {
    selectTemplate(id)
    onNext()
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:py-12">
      <button
        onClick={onBack}
        className="mb-6 inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Change role
      </button>

      <div className="max-w-2xl">
        <h1 className="text-balance text-3xl font-bold tracking-tight">
          Pick a template{role ? ` for ${role.name}` : ''}
        </h1>
        <p className="mt-2 text-pretty text-muted-foreground">
          Starred templates are recommended for your role. You can switch
          templates anytime while editing — your content stays intact.
        </p>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {ordered.map((t) => {
          const isRec = recommended.includes(t.id)
          const active = data.templateId === t.id
          return (
            <div
              key={t.id}
              className={cn(
                'group flex flex-col overflow-hidden rounded-xl border bg-card shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md',
                active ? 'border-primary ring-2 ring-primary/20' : 'border-border',
              )}
            >
              <div className="relative">
                <TemplateThumb templateId={t.id} accent={data.accentColor} />
                {isRec && (
                  <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-[11px] font-semibold text-primary-foreground shadow">
                    <Star className="h-3 w-3 fill-current" />
                    Recommended
                  </span>
                )}
                {active && (
                  <span className="absolute right-2 top-2 inline-flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground shadow">
                    <Check className="h-3.5 w-3.5" />
                  </span>
                )}
              </div>
              <div className="flex flex-1 flex-col p-4">
                <div className="flex items-baseline justify-between gap-2">
                  <h3 className="font-semibold text-card-foreground">{t.name}</h3>
                  <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
                    {t.tagline}
                  </span>
                </div>
                <p className="mt-1 flex-1 text-sm leading-relaxed text-muted-foreground">
                  {t.description}
                </p>
                <Button
                  onClick={() => pick(t.id)}
                  variant={active ? 'default' : 'outline'}
                  className="mt-4 w-full"
                >
                  {active ? 'Continue with this template' : 'Use this template'}
                </Button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
