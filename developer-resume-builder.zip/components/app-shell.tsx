'use client'

import { FileText } from 'lucide-react'

export function AppShell({
  children,
  right,
}: {
  children: React.ReactNode
  right?: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="no-print sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <FileText className="h-4 w-4" />
            </span>
            <span className="text-base font-semibold tracking-tight">
              ResuMint
            </span>
          </div>
          <div className="flex items-center gap-2">{right}</div>
        </div>
      </header>
      <div className="flex-1">{children}</div>
    </div>
  )
}
