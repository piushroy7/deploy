'use client'

import { useState } from 'react'
import { ArrowRight, Sparkles } from 'lucide-react'
import { CATEGORIES, ROLES, type RoleCategory } from '@/lib/roles'
import { useResume } from '@/lib/resume-context'
import { cn } from '@/lib/utils'

export function StageRole({ onNext }: { onNext: () => void }) {
  const { selectRole, data } = useResume()
  const [category, setCategory] = useState<RoleCategory>(
    (ROLES.find((r) => r.id === data.roleId)?.category ?? 'technical') as RoleCategory,
  )

  const roles = ROLES.filter((r) => r.category === category)

  function pick(id: string) {
    selectRole(id)
    onNext()
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:py-16">
      <div className="mx-auto max-w-2xl text-center">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          Resume builder for developers &amp; beyond
        </span>
        <h1 className="mt-4 text-balance text-4xl font-bold tracking-tight md:text-5xl">
          Build a resume tailored to your role
        </h1>
        <p className="mt-4 text-pretty text-base leading-relaxed text-muted-foreground">
          Choose your role and we&apos;ll surface the templates and sections that
          work best for it. Fill in your details step by step, then export a clean
          PDF.
        </p>
      </div>

      {/* category switch */}
      <div className="mx-auto mt-10 flex max-w-md items-center justify-center gap-1 rounded-lg border border-border bg-secondary p-1">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setCategory(c.id)}
            className={cn(
              'flex-1 rounded-md px-4 py-2 text-sm font-medium transition-colors',
              category === c.id
                ? 'bg-background text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground',
            )}
          >
            {c.label}
          </button>
        ))}
      </div>
      <p className="mx-auto mt-3 max-w-md text-center text-sm text-muted-foreground">
        {CATEGORIES.find((c) => c.id === category)?.description}
      </p>

      {/* roles grid */}
      <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {roles.map((role) => {
          const Icon = role.icon
          const active = data.roleId === role.id
          return (
            <button
              key={role.id}
              onClick={() => pick(role.id)}
              className={cn(
                'group flex items-start gap-3 rounded-xl border bg-card p-4 text-left transition-all hover:-translate-y-0.5 hover:shadow-md',
                active
                  ? 'border-primary ring-2 ring-primary/20'
                  : 'border-border hover:border-primary/40',
              )}
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Icon className="h-5 w-5" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-card-foreground">
                    {role.name}
                  </span>
                  <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                </span>
                <span className="mt-0.5 block text-sm text-muted-foreground">
                  {role.blurb}
                </span>
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
