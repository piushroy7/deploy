import type { ResumeData } from '@/lib/resume-types'

/* ---------- shared helpers ---------- */

function hasText(s?: string) {
  return !!s && s.trim().length > 0
}

function contactList(data: ResumeData): string[] {
  return [
    data.email,
    data.phone,
    data.location,
    data.website,
    data.linkedin,
    data.github,
  ].filter(hasText)
}

function dateRange(start: string, end: string, current?: boolean) {
  const e = current ? 'Present' : end
  if (hasText(start) && hasText(e)) return `${start} — ${e}`
  return start || e || ''
}

type TemplateProps = { data: ResumeData; accent: string }

/* ============================================================
   MODERN — colored sidebar
============================================================ */
function ModernTemplate({ data, accent }: TemplateProps) {
  const contacts = contactList(data)
  return (
    <div className="resume-sheet flex min-h-full bg-white text-[13px] leading-relaxed text-neutral-800">
      {/* sidebar */}
      <aside
        className="w-[34%] shrink-0 p-7 text-white"
        style={{ backgroundColor: accent }}
      >
        <h1 className="text-2xl font-bold leading-tight text-balance">
          {hasText(data.fullName) ? data.fullName : 'Your Name'}
        </h1>
        {hasText(data.headline) && (
          <p className="mt-1 text-sm text-white/80">{data.headline}</p>
        )}

        {contacts.length > 0 && (
          <section className="mt-7">
            <h2 className="mb-2 text-xs font-semibold uppercase tracking-widest text-white/70">
              Contact
            </h2>
            <ul className="space-y-1.5 break-words text-[12px] text-white/90">
              {contacts.map((c) => (
                <li key={c}>{c}</li>
              ))}
            </ul>
          </section>
        )}

        {data.skillGroups.length > 0 && (
          <section className="mt-7">
            <h2 className="mb-2 text-xs font-semibold uppercase tracking-widest text-white/70">
              Skills
            </h2>
            <div className="space-y-3">
              {data.skillGroups.map((g) => (
                <div key={g.id}>
                  {hasText(g.name) && (
                    <p className="text-[12px] font-semibold text-white">
                      {g.name}
                    </p>
                  )}
                  <p className="text-[12px] text-white/85">
                    {g.skills.join(', ')}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.certifications.length > 0 && (
          <section className="mt-7">
            <h2 className="mb-2 text-xs font-semibold uppercase tracking-widest text-white/70">
              Certifications
            </h2>
            <ul className="space-y-2 text-[12px] text-white/90">
              {data.certifications.map((c) => (
                <li key={c.id}>
                  <span className="font-medium text-white">{c.name}</span>
                  <br />
                  {[c.issuer, c.date].filter(hasText).join(' · ')}
                </li>
              ))}
            </ul>
          </section>
        )}
      </aside>

      {/* main */}
      <main className="flex-1 p-8">
        {hasText(data.summary) && (
          <Section title="Profile" accent={accent}>
            <p>{data.summary}</p>
          </Section>
        )}

        {data.experience.length > 0 && (
          <Section title="Experience" accent={accent}>
            <div className="space-y-4">
              {data.experience.map((x) => (
                <div key={x.id}>
                  <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                    <h3 className="font-semibold text-neutral-900">
                      {x.role || 'Role'}
                    </h3>
                    <span className="text-[12px] text-neutral-500">
                      {dateRange(x.startDate, x.endDate, x.current)}
                    </span>
                  </div>
                  <p className="text-[12.5px] font-medium" style={{ color: accent }}>
                    {[x.company, x.location].filter(hasText).join(' · ')}
                  </p>
                  <BulletList bullets={x.bullets} />
                </div>
              ))}
            </div>
          </Section>
        )}

        {data.projects.length > 0 && (
          <Section title="Projects" accent={accent}>
            <div className="space-y-3">
              {data.projects.map((p) => (
                <div key={p.id}>
                  <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                    <h3 className="font-semibold text-neutral-900">{p.name}</h3>
                    {hasText(p.link) && (
                      <span className="text-[12px] text-neutral-500">{p.link}</span>
                    )}
                  </div>
                  {hasText(p.description) && <p>{p.description}</p>}
                  {p.tech.length > 0 && (
                    <p className="mt-0.5 text-[12px] text-neutral-500">
                      {p.tech.join(' · ')}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </Section>
        )}

        {data.education.length > 0 && (
          <Section title="Education" accent={accent}>
            <div className="space-y-2">
              {data.education.map((e) => (
                <EducationRow key={e.id} e={e} />
              ))}
            </div>
          </Section>
        )}
      </main>
    </div>
  )
}

function Section({
  title,
  accent,
  children,
}: {
  title: string
  accent: string
  children: React.ReactNode
}) {
  return (
    <section className="mb-5 last:mb-0">
      <h2
        className="mb-2 border-b pb-1 text-sm font-bold uppercase tracking-wide"
        style={{ color: accent, borderColor: `${accent}33` }}
      >
        {title}
      </h2>
      {children}
    </section>
  )
}

function BulletList({ bullets }: { bullets: string[] }) {
  const items = bullets.filter(hasText)
  if (items.length === 0) return null
  return (
    <ul className="mt-1 list-disc space-y-0.5 pl-4 marker:text-neutral-400">
      {items.map((b, i) => (
        <li key={i}>{b}</li>
      ))}
    </ul>
  )
}

function EducationRow({ e }: { e: ResumeData['education'][number] }) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-x-2">
      <div>
        <span className="font-semibold text-neutral-900">{e.school}</span>
        {(hasText(e.degree) || hasText(e.field)) && (
          <span className="text-neutral-600">
            {' '}
            — {[e.degree, e.field].filter(hasText).join(', ')}
          </span>
        )}
      </div>
      <span className="text-[12px] text-neutral-500">
        {dateRange(e.startDate, e.endDate)}
      </span>
    </div>
  )
}

/* ============================================================
   TECHNICAL — mono accents + skill matrix
============================================================ */
function TechnicalTemplate({ data, accent }: TemplateProps) {
  const contacts = contactList(data)
  return (
    <div className="resume-sheet min-h-full bg-white p-9 text-[13px] leading-relaxed text-neutral-800">
      <header className="border-b-2 pb-3" style={{ borderColor: accent }}>
        <h1 className="font-mono text-3xl font-bold text-neutral-900">
          {hasText(data.fullName) ? data.fullName : 'Your Name'}
        </h1>
        {hasText(data.headline) && (
          <p className="mt-1 font-mono text-sm" style={{ color: accent }}>
            {'// '}
            {data.headline}
          </p>
        )}
        {contacts.length > 0 && (
          <p className="mt-2 font-mono text-[12px] text-neutral-500">
            {contacts.join('  ·  ')}
          </p>
        )}
      </header>

      {hasText(data.summary) && (
        <TechSection title="summary" accent={accent}>
          <p>{data.summary}</p>
        </TechSection>
      )}

      {data.skillGroups.length > 0 && (
        <TechSection title="skills" accent={accent}>
          <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
            {data.skillGroups.map((g) => (
              <div key={g.id} className="flex gap-2">
                <span
                  className="shrink-0 font-mono text-[12px] font-semibold"
                  style={{ color: accent }}
                >
                  {(g.name || 'misc').toLowerCase()}:
                </span>
                <span className="text-[12.5px]">{g.skills.join(', ')}</span>
              </div>
            ))}
          </div>
        </TechSection>
      )}

      {data.experience.length > 0 && (
        <TechSection title="experience" accent={accent}>
          <div className="space-y-4">
            {data.experience.map((x) => (
              <div key={x.id}>
                <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                  <h3 className="font-semibold text-neutral-900">
                    {x.role || 'Role'}
                    <span className="font-normal text-neutral-500">
                      {' '}
                      @ {x.company}
                    </span>
                  </h3>
                  <span className="font-mono text-[12px] text-neutral-500">
                    {dateRange(x.startDate, x.endDate, x.current)}
                  </span>
                </div>
                <BulletList bullets={x.bullets} />
              </div>
            ))}
          </div>
        </TechSection>
      )}

      {data.projects.length > 0 && (
        <TechSection title="projects" accent={accent}>
          <div className="space-y-3">
            {data.projects.map((p) => (
              <div key={p.id}>
                <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                  <h3 className="font-mono font-semibold text-neutral-900">
                    {p.name}
                  </h3>
                  {hasText(p.link) && (
                    <span className="font-mono text-[12px] text-neutral-500">
                      {p.link}
                    </span>
                  )}
                </div>
                {hasText(p.description) && <p>{p.description}</p>}
                {p.tech.length > 0 && (
                  <p
                    className="mt-0.5 font-mono text-[11.5px]"
                    style={{ color: accent }}
                  >
                    [{p.tech.join(', ')}]
                  </p>
                )}
              </div>
            ))}
          </div>
        </TechSection>
      )}

      {data.education.length > 0 && (
        <TechSection title="education" accent={accent}>
          <div className="space-y-2">
            {data.education.map((e) => (
              <EducationRow key={e.id} e={e} />
            ))}
          </div>
        </TechSection>
      )}

      {data.certifications.length > 0 && (
        <TechSection title="certifications" accent={accent}>
          <ul className="list-disc space-y-1 pl-4 marker:text-neutral-400">
            {data.certifications.map((c) => (
              <li key={c.id}>
                {[c.name, c.issuer, c.date].filter(hasText).join(' · ')}
              </li>
            ))}
          </ul>
        </TechSection>
      )}
    </div>
  )
}

function TechSection({
  title,
  accent,
  children,
}: {
  title: string
  accent: string
  children: React.ReactNode
}) {
  return (
    <section className="mt-5">
      <h2 className="mb-2 font-mono text-sm font-bold text-neutral-900">
        <span style={{ color: accent }}>#</span> {title}
      </h2>
      {children}
    </section>
  )
}

/* ============================================================
   MINIMAL — airy, quiet typography
============================================================ */
function MinimalTemplate({ data, accent }: TemplateProps) {
  const contacts = contactList(data)
  return (
    <div className="resume-sheet min-h-full bg-white px-12 py-12 text-[13px] leading-relaxed text-neutral-700">
      <header className="text-center">
        <h1 className="text-3xl font-light tracking-wide text-neutral-900">
          {hasText(data.fullName) ? data.fullName : 'Your Name'}
        </h1>
        {hasText(data.headline) && (
          <p className="mt-2 text-sm uppercase tracking-[0.2em] text-neutral-500">
            {data.headline}
          </p>
        )}
        {contacts.length > 0 && (
          <p className="mt-3 text-[12px] text-neutral-500">
            {contacts.join('  ·  ')}
          </p>
        )}
      </header>

      <div
        className="mx-auto mt-6 h-px w-16"
        style={{ backgroundColor: accent }}
      />

      {hasText(data.summary) && (
        <p className="mx-auto mt-6 max-w-prose text-center">{data.summary}</p>
      )}

      {data.experience.length > 0 && (
        <MinSection title="Experience">
          <div className="space-y-5">
            {data.experience.map((x) => (
              <div key={x.id}>
                <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                  <h3 className="font-medium text-neutral-900">
                    {x.role} {hasText(x.company) && <span className="text-neutral-500">· {x.company}</span>}
                  </h3>
                  <span className="text-[12px] text-neutral-400">
                    {dateRange(x.startDate, x.endDate, x.current)}
                  </span>
                </div>
                <BulletList bullets={x.bullets} />
              </div>
            ))}
          </div>
        </MinSection>
      )}

      {data.projects.length > 0 && (
        <MinSection title="Projects">
          <div className="space-y-3">
            {data.projects.map((p) => (
              <div key={p.id}>
                <h3 className="font-medium text-neutral-900">{p.name}</h3>
                {hasText(p.description) && <p>{p.description}</p>}
                {p.tech.length > 0 && (
                  <p className="text-[12px] text-neutral-400">
                    {p.tech.join(' · ')}
                  </p>
                )}
              </div>
            ))}
          </div>
        </MinSection>
      )}

      {data.skillGroups.length > 0 && (
        <MinSection title="Skills">
          <p className="text-center">
            {data.skillGroups.flatMap((g) => g.skills).join('  ·  ')}
          </p>
        </MinSection>
      )}

      {data.education.length > 0 && (
        <MinSection title="Education">
          <div className="space-y-2">
            {data.education.map((e) => (
              <EducationRow key={e.id} e={e} />
            ))}
          </div>
        </MinSection>
      )}

      {data.certifications.length > 0 && (
        <MinSection title="Certifications">
          <p className="text-center">
            {data.certifications
              .map((c) => [c.name, c.issuer].filter(hasText).join(', '))
              .join('  ·  ')}
          </p>
        </MinSection>
      )}
    </div>
  )
}

function MinSection({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <section className="mt-7">
      <h2 className="mb-3 text-center text-xs font-semibold uppercase tracking-[0.25em] text-neutral-400">
        {title}
      </h2>
      {children}
    </section>
  )
}

/* ============================================================
   CLASSIC — traditional serif, ATS-friendly
============================================================ */
function ClassicTemplate({ data, accent }: TemplateProps) {
  const contacts = contactList(data)
  return (
    <div className="resume-sheet min-h-full bg-white px-10 py-10 font-serif text-[13px] leading-relaxed text-neutral-900">
      <header className="border-b-2 border-neutral-800 pb-3 text-center">
        <h1 className="text-3xl font-bold tracking-wide">
          {hasText(data.fullName) ? data.fullName : 'Your Name'}
        </h1>
        {hasText(data.headline) && (
          <p className="mt-1 text-sm text-neutral-600">{data.headline}</p>
        )}
        {contacts.length > 0 && (
          <p className="mt-2 text-[12px] text-neutral-600">
            {contacts.join('  |  ')}
          </p>
        )}
      </header>

      {hasText(data.summary) && (
        <ClassicSection title="Professional Summary" accent={accent}>
          <p>{data.summary}</p>
        </ClassicSection>
      )}

      {data.experience.length > 0 && (
        <ClassicSection title="Professional Experience" accent={accent}>
          <div className="space-y-3">
            {data.experience.map((x) => (
              <div key={x.id}>
                <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                  <h3 className="font-bold">{x.company || 'Company'}</h3>
                  <span className="text-[12px] italic text-neutral-600">
                    {dateRange(x.startDate, x.endDate, x.current)}
                  </span>
                </div>
                <p className="italic text-neutral-700">
                  {[x.role, x.location].filter(hasText).join(', ')}
                </p>
                <BulletList bullets={x.bullets} />
              </div>
            ))}
          </div>
        </ClassicSection>
      )}

      {data.education.length > 0 && (
        <ClassicSection title="Education" accent={accent}>
          <div className="space-y-2">
            {data.education.map((e) => (
              <div
                key={e.id}
                className="flex flex-wrap items-baseline justify-between gap-x-2"
              >
                <div>
                  <span className="font-bold">{e.school}</span>
                  {(hasText(e.degree) || hasText(e.field)) && (
                    <span className="italic">
                      {' '}
                      — {[e.degree, e.field].filter(hasText).join(', ')}
                    </span>
                  )}
                </div>
                <span className="text-[12px] italic text-neutral-600">
                  {dateRange(e.startDate, e.endDate)}
                </span>
              </div>
            ))}
          </div>
        </ClassicSection>
      )}

      {data.skillGroups.length > 0 && (
        <ClassicSection title="Skills" accent={accent}>
          <ul className="space-y-1">
            {data.skillGroups.map((g) => (
              <li key={g.id}>
                {hasText(g.name) && <span className="font-bold">{g.name}: </span>}
                {g.skills.join(', ')}
              </li>
            ))}
          </ul>
        </ClassicSection>
      )}

      {data.projects.length > 0 && (
        <ClassicSection title="Projects" accent={accent}>
          <div className="space-y-2">
            {data.projects.map((p) => (
              <div key={p.id}>
                <span className="font-bold">{p.name}</span>
                {hasText(p.description) && <span> — {p.description}</span>}
              </div>
            ))}
          </div>
        </ClassicSection>
      )}

      {data.certifications.length > 0 && (
        <ClassicSection title="Certifications" accent={accent}>
          <ul className="list-disc space-y-1 pl-5">
            {data.certifications.map((c) => (
              <li key={c.id}>
                {[c.name, c.issuer, c.date].filter(hasText).join(', ')}
              </li>
            ))}
          </ul>
        </ClassicSection>
      )}
    </div>
  )
}

function ClassicSection({
  title,
  accent,
  children,
}: {
  title: string
  accent: string
  children: React.ReactNode
}) {
  return (
    <section className="mt-5">
      <h2
        className="mb-2 text-sm font-bold uppercase tracking-wide"
        style={{ color: accent }}
      >
        {title}
      </h2>
      <div className="border-t border-neutral-300 pt-2">{children}</div>
    </section>
  )
}

/* ============================================================
   ELEGANT — centered header w/ accent band
============================================================ */
function ElegantTemplate({ data, accent }: TemplateProps) {
  const contacts = contactList(data)
  return (
    <div className="resume-sheet min-h-full bg-white text-[13px] leading-relaxed text-neutral-700">
      <header
        className="px-10 py-9 text-center text-white"
        style={{ backgroundColor: accent }}
      >
        <h1 className="text-3xl font-semibold tracking-wide">
          {hasText(data.fullName) ? data.fullName : 'Your Name'}
        </h1>
        {hasText(data.headline) && (
          <p className="mt-1 text-sm text-white/85">{data.headline}</p>
        )}
        {contacts.length > 0 && (
          <p className="mt-3 text-[12px] text-white/80">
            {contacts.join('   ·   ')}
          </p>
        )}
      </header>

      <div className="px-10 py-8">
        {hasText(data.summary) && (
          <ElegantSection title="About" accent={accent}>
            <p>{data.summary}</p>
          </ElegantSection>
        )}

        {data.experience.length > 0 && (
          <ElegantSection title="Experience" accent={accent}>
            <div className="space-y-4">
              {data.experience.map((x) => (
                <div key={x.id}>
                  <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                    <h3 className="font-semibold text-neutral-900">
                      {[x.role, x.company].filter(hasText).join(' · ')}
                    </h3>
                    <span className="text-[12px] text-neutral-400">
                      {dateRange(x.startDate, x.endDate, x.current)}
                    </span>
                  </div>
                  <BulletList bullets={x.bullets} />
                </div>
              ))}
            </div>
          </ElegantSection>
        )}

        {data.projects.length > 0 && (
          <ElegantSection title="Projects" accent={accent}>
            <div className="space-y-3">
              {data.projects.map((p) => (
                <div key={p.id}>
                  <h3 className="font-semibold text-neutral-900">{p.name}</h3>
                  {hasText(p.description) && <p>{p.description}</p>}
                  {p.tech.length > 0 && (
                    <p className="text-[12px] text-neutral-400">
                      {p.tech.join(' · ')}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </ElegantSection>
        )}

        <div className="grid grid-cols-1 gap-x-8 sm:grid-cols-2">
          {data.skillGroups.length > 0 && (
            <ElegantSection title="Skills" accent={accent}>
              <div className="space-y-2">
                {data.skillGroups.map((g) => (
                  <div key={g.id}>
                    {hasText(g.name) && (
                      <p className="font-semibold text-neutral-900">{g.name}</p>
                    )}
                    <p>{g.skills.join(', ')}</p>
                  </div>
                ))}
              </div>
            </ElegantSection>
          )}

          <div>
            {data.education.length > 0 && (
              <ElegantSection title="Education" accent={accent}>
                <div className="space-y-2">
                  {data.education.map((e) => (
                    <div key={e.id}>
                      <p className="font-semibold text-neutral-900">{e.school}</p>
                      <p className="text-[12px]">
                        {[e.degree, e.field].filter(hasText).join(', ')}
                      </p>
                      <p className="text-[12px] text-neutral-400">
                        {dateRange(e.startDate, e.endDate)}
                      </p>
                    </div>
                  ))}
                </div>
              </ElegantSection>
            )}

            {data.certifications.length > 0 && (
              <ElegantSection title="Certifications" accent={accent}>
                <ul className="space-y-1">
                  {data.certifications.map((c) => (
                    <li key={c.id}>
                      {[c.name, c.issuer].filter(hasText).join(', ')}
                    </li>
                  ))}
                </ul>
              </ElegantSection>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function ElegantSection({
  title,
  accent,
  children,
}: {
  title: string
  accent: string
  children: React.ReactNode
}) {
  return (
    <section className="mb-5 last:mb-0">
      <h2
        className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em]"
        style={{ color: accent }}
      >
        {title}
        <span className="h-px flex-1" style={{ backgroundColor: `${accent}33` }} />
      </h2>
      {children}
    </section>
  )
}

/* ============================================================
   COMPACT — dense two-column
============================================================ */
function CompactTemplate({ data, accent }: TemplateProps) {
  const contacts = contactList(data)
  return (
    <div className="resume-sheet min-h-full bg-white px-9 py-8 text-[12.5px] leading-snug text-neutral-800">
      <header className="mb-4 flex flex-wrap items-end justify-between gap-2 border-b pb-2" style={{ borderColor: accent }}>
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">
            {hasText(data.fullName) ? data.fullName : 'Your Name'}
          </h1>
          {hasText(data.headline) && (
            <p className="text-[13px] font-medium" style={{ color: accent }}>
              {data.headline}
            </p>
          )}
        </div>
        {contacts.length > 0 && (
          <p className="max-w-[55%] text-right text-[11.5px] text-neutral-500">
            {contacts.join(' · ')}
          </p>
        )}
      </header>

      {hasText(data.summary) && (
        <p className="mb-4 text-neutral-700">{data.summary}</p>
      )}

      <div className="grid grid-cols-1 gap-x-7 md:grid-cols-3">
        {/* left rail */}
        <div className="md:col-span-1">
          {data.skillGroups.length > 0 && (
            <CompactSection title="Skills" accent={accent}>
              <div className="space-y-2">
                {data.skillGroups.map((g) => (
                  <div key={g.id}>
                    {hasText(g.name) && (
                      <p className="font-semibold text-neutral-900">{g.name}</p>
                    )}
                    <p className="text-neutral-600">{g.skills.join(', ')}</p>
                  </div>
                ))}
              </div>
            </CompactSection>
          )}

          {data.education.length > 0 && (
            <CompactSection title="Education" accent={accent}>
              <div className="space-y-2">
                {data.education.map((e) => (
                  <div key={e.id}>
                    <p className="font-semibold text-neutral-900">{e.school}</p>
                    <p className="text-neutral-600">
                      {[e.degree, e.field].filter(hasText).join(', ')}
                    </p>
                    <p className="text-[11px] text-neutral-400">
                      {dateRange(e.startDate, e.endDate)}
                    </p>
                  </div>
                ))}
              </div>
            </CompactSection>
          )}

          {data.certifications.length > 0 && (
            <CompactSection title="Certifications" accent={accent}>
              <ul className="space-y-1 text-neutral-600">
                {data.certifications.map((c) => (
                  <li key={c.id}>{[c.name, c.date].filter(hasText).join(' · ')}</li>
                ))}
              </ul>
            </CompactSection>
          )}
        </div>

        {/* main rail */}
        <div className="md:col-span-2">
          {data.experience.length > 0 && (
            <CompactSection title="Experience" accent={accent}>
              <div className="space-y-3">
                {data.experience.map((x) => (
                  <div key={x.id}>
                    <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                      <h3 className="font-semibold text-neutral-900">
                        {x.role}
                        {hasText(x.company) && (
                          <span className="font-normal text-neutral-500">
                            {' '}
                            · {x.company}
                          </span>
                        )}
                      </h3>
                      <span className="text-[11px] text-neutral-400">
                        {dateRange(x.startDate, x.endDate, x.current)}
                      </span>
                    </div>
                    <BulletList bullets={x.bullets} />
                  </div>
                ))}
              </div>
            </CompactSection>
          )}

          {data.projects.length > 0 && (
            <CompactSection title="Projects" accent={accent}>
              <div className="space-y-2">
                {data.projects.map((p) => (
                  <div key={p.id}>
                    <h3 className="font-semibold text-neutral-900">
                      {p.name}
                      {hasText(p.link) && (
                        <span className="font-normal text-neutral-400">
                          {' '}
                          — {p.link}
                        </span>
                      )}
                    </h3>
                    {hasText(p.description) && (
                      <p className="text-neutral-700">{p.description}</p>
                    )}
                    {p.tech.length > 0 && (
                      <p className="text-[11px] text-neutral-400">
                        {p.tech.join(' · ')}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </CompactSection>
          )}
        </div>
      </div>
    </div>
  )
}

function CompactSection({
  title,
  accent,
  children,
}: {
  title: string
  accent: string
  children: React.ReactNode
}) {
  return (
    <section className="mb-4 last:mb-0">
      <h2
        className="mb-1.5 text-[11px] font-bold uppercase tracking-widest"
        style={{ color: accent }}
      >
        {title}
      </h2>
      {children}
    </section>
  )
}

/* ============================================================
   Renderer
============================================================ */
export function TemplateRenderer({ data }: { data: ResumeData }) {
  const accent = data.accentColor || '#4f5bd5'
  const props = { data, accent }
  switch (data.templateId) {
    case 'technical':
      return <TechnicalTemplate {...props} />
    case 'minimal':
      return <MinimalTemplate {...props} />
    case 'classic':
      return <ClassicTemplate {...props} />
    case 'elegant':
      return <ElegantTemplate {...props} />
    case 'compact':
      return <CompactTemplate {...props} />
    case 'modern':
    default:
      return <ModernTemplate {...props} />
  }
}
