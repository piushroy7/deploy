'use client'

import { Download, Check } from 'lucide-react'
import { useResume } from '@/lib/resume-context'
import { ACCENT_PRESETS } from '@/lib/resume-types'
import { TEMPLATES } from '@/lib/templates'
import { TemplateRenderer } from '@/components/resume/template-renderer'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'

export function PreviewPane() {
  const { data, selectTemplate, setField } = useResume()

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-[280px_1fr]">
      {/* customization rail */}
      <aside className="no-print space-y-6 lg:sticky lg:top-20 lg:self-start">
        <div className="rounded-xl border border-border bg-card p-4">
          <h3 className="text-sm font-semibold text-card-foreground">Export</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Opens your browser print dialog. Choose &ldquo;Save as PDF&rdquo; as
            the destination for a crisp, selectable PDF.
          </p>
          <Button className="mt-3 w-full" onClick={() => window.print()}>
            <Download className="h-4 w-4" /> Download PDF
          </Button>
        </div>

        <div className="rounded-xl border border-border bg-card p-4">
          <Label className="text-sm font-semibold text-card-foreground">
            Template
          </Label>
          <Select value={data.templateId} onValueChange={selectTemplate}>
            <SelectTrigger className="mt-2 w-full">
              <SelectValue placeholder="Choose template" />
            </SelectTrigger>
            <SelectContent>
              {TEMPLATES.map((t) => (
                <SelectItem key={t.id} value={t.id}>
                  {t.name} — {t.tagline}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="rounded-xl border border-border bg-card p-4">
          <Label className="text-sm font-semibold text-card-foreground">
            Accent color
          </Label>
          <div className="mt-3 flex flex-wrap gap-2">
            {ACCENT_PRESETS.map((c) => {
              const active = data.accentColor.toLowerCase() === c.value.toLowerCase()
              return (
                <button
                  key={c.value}
                  title={c.name}
                  onClick={() => setField('accentColor', c.value)}
                  className={cn(
                    'flex h-8 w-8 items-center justify-center rounded-full ring-2 ring-offset-2 ring-offset-card transition-all',
                    active ? 'ring-foreground' : 'ring-transparent',
                  )}
                  style={{ backgroundColor: c.value }}
                >
                  {active && <Check className="h-4 w-4 text-white" />}
                </button>
              )
            })}
            <label
              className="relative flex h-8 w-8 cursor-pointer items-center justify-center overflow-hidden rounded-full border border-dashed border-border text-[10px] text-muted-foreground"
              title="Custom color"
            >
              <input
                type="color"
                value={data.accentColor}
                onChange={(e) => setField('accentColor', e.target.value)}
                className="h-10 w-10 cursor-pointer opacity-0"
              />
              <span className="pointer-events-none absolute">＋</span>
            </label>
          </div>
        </div>
      </aside>

      {/* the resume sheet */}
      <div className="min-w-0">
        <div
          id="print-area"
          className="overflow-hidden rounded-xl border border-border bg-white shadow-lg"
        >
          <TemplateRenderer data={data} />
        </div>
      </div>
    </div>
  )
}
